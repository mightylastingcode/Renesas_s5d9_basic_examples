/**************************************************************************/ 
/*                                                                        */ 
/*            Copyright (c) 1996-2012 by Express Logic Inc.               */ 
/*                                                                        */ 
/*  This software is copyrighted by and is the sole property of Express   */ 
/*  Logic, Inc.  All rights, title, ownership, or other interests         */ 
/*  in the software remain the property of Express Logic, Inc.  This      */ 
/*  software may only be used in accordance with the corresponding        */ 
/*  license agreement.  Any unauthorized use, duplication, transmission,  */ 
/*  distribution, or disclosure of this software is expressly forbidden.  */ 
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */ 
/*  written consent of Express Logic, Inc.                                */ 
/*                                                                        */ 
/*  Express Logic, Inc. reserves the right to modify this software        */ 
/*  without notice.                                                       */ 
/*                                                                        */ 
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               www.expresslogic.com          */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/

/***********************************************************************************************************************
 * Copyright [2017] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
 * 
 * This file is part of Renesas SynergyTM Software Package (SSP)
 *
 * The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
 * and/or its licensors ("Renesas") and subject to statutory and contractual protections.
 *
 * This file is subject to a Renesas SSP license agreement. Unless otherwise agreed in an SSP license agreement with
 * Renesas: 1) you may not use, copy, modify, distribute, display, or perform the contents; 2) you may not use any name
 * or mark of Renesas for advertising or publicity purposes or in connection with your use of the contents; 3) RENESAS
 * MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED
 * "AS IS" WITHOUT ANY EXPRESS OR IMPLIED WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR
 * CONSEQUENTIAL DAMAGES, INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF
 * CONTRACT OR TORT, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents
 * included in this file may be subject to different terms.
 **********************************************************************************************************************/

/**************************************************************************/
/**************************************************************************/
/**                                                                       */ 
/** USBX Component                                                        */ 
/**                                                                       */
/**   SYNERGY Controller Driver                                           */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/


/* Include necessary system files.  */

#define UX_SOURCE_CODE

#include "ux_api.h"
#include "ux_hcd_synergy.h"
#include "ux_utility.h"
#include "r_transfer_api.h"

static VOID ux_hcd_synergy_fifo_read_software_copy(UX_HCD_SYNERGY *hcd_synergy,
                        ULONG payload_length, UCHAR *payload_buffer, VOID * fifo_addr, ULONG fifo_sel, ULONG fifo_ctrl);

static VOID ux_hcd_synergy_fifo_read_software_copy_16bit(UX_HCD_SYNERGY *hcd_synergy,
        ULONG payload_length, UCHAR *payload_buffer, VOID * fifo_addr, ULONG fifo_sel, ULONG fifo_ctrl);

static VOID ux_hcd_synergy_fifo_read_software_copy_8bit(UX_HCD_SYNERGY *hcd_synergy,
        ULONG payload_length, UCHAR *payload_buffer, VOID * fifo_addr, ULONG fifo_sel, ULONG fifo_ctrl);

/*******************************************************************************************************************//**
 * @addtogroup sf_el_ux
 * @{
 **********************************************************************************************************************/

/**************************************************************************/ 
/*                                                                        */ 
/*  FUNCTION                                               RELEASE        */ 
/*                                                                        */ 
/*    ux_hcd_synergy_fifo_read                            PORTABLE C      */
/*                                                           5.6          */ 
/*  AUTHOR                                                                */ 
/*                                                                        */ 
/*    Thierry Giron, Express Logic Inc.                                   */ 
/*                                                                        */ 
/*  DESCRIPTION                                                           */ 
/*                                                                        */ 
/*    This function reads a buffer from FIFO C D0 or D1                   */ 
/*                                                                        */ 
/*  INPUT                                                                 */ 
/*                                                                        */ 
/*    hcd_synergy                           Pointer to Synergy controller */
/*    ed                                    Register to the ed            */
/*                                                                        */ 
/*  OUTPUT                                                                */ 
/*                                                                        */ 
/*    status                                                              */ 
/*                                                                        */ 
/*  CALLS                                                                 */ 
/*                                                                        */ 
/*    None                                                                */ 
/*                                                                        */ 
/*  CALLED BY                                                             */ 
/*                                                                        */ 
/*    Synergy Controller Driver                                           */
/*                                                                        */ 
/*  RELEASE HISTORY                                                       */ 
/*                                                                        */ 
/*    DATE              NAME                      DESCRIPTION             */ 
/*                                                                        */ 
/*  10-10-2012     TCRG                     Initial Version 5.6           */ 
/*                                                                        */ 
/**************************************************************************/ 

/***********************************************************************************************************************
 * Functions
 **********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief This function read data from the FIFO configured for the PIPE(FIFO C, D0 or D1).
 *
 * @param[in,out]  hcd_synergy : Pointer to a HCD control block
 * @param[in]      ed          : Pointer to Synergy ED structure
 *
 * @retval UX_ERROR                        Unable to access FIFO successfully.
 * @retval UX_SYNERGY_HC_FIFO_READ_OVER    Status set to read overflow.
 * @retval UX_SYNERGY_HC_FIFO_READ_SHORT   Short packet to read.
 * @retval UX_SYNERGY_HC_FIFO_READING      Continue reading buffer.
 **********************************************************************************************************************/
UINT  ux_hcd_synergy_fifo_read(UX_HCD_SYNERGY *hcd_synergy, UX_SYNERGY_ED *ed)
{
    UX_SYNERGY_TD * td;
    ULONG           fifo_access_status;
    ULONG           max_packet_size;
    ULONG           payload_length;
    UINT            status;
    UCHAR         * payload_buffer;
    ULONG           transfer_length_width = 0;
    ULONG           fifo_sel = 0;
    VOID          * fifo_addr = NULL;
    ULONG           fifo_ctrl = 0;

    /* We need to select the FIFO registers.  */
    switch (ed -> ux_synergy_fifo_index)
    {
        case (ULONG)UX_SYNERGY_HC_FIFO_D0 :

            /* Set fifo_sel and fifo_addr fields to FIFO_D0 */
            fifo_sel  =  UX_SYNERGY_HC_D0FIFOSEL;
            fifo_addr =  (VOID *)(hcd_synergy->ux_hcd_synergy_base + UX_SYNERGY_HC_D0FIFO);
            fifo_ctrl =  UX_SYNERGY_HC_D0FIFOCTR;
            break;

        case (ULONG)UX_SYNERGY_HC_FIFO_D1 :

            /* Set fifo_sel and fifo_addr fields to FIFO_D1 */
            fifo_sel  =  UX_SYNERGY_HC_D1FIFOSEL;
            fifo_addr =  (VOID *)(hcd_synergy->ux_hcd_synergy_base + UX_SYNERGY_HC_D1FIFO);
            fifo_ctrl =  UX_SYNERGY_HC_D1FIFOCTR;
            break;

        default :

            /* Set fifo_sel and fifo_addr fields to FIFO_C */
            fifo_sel  =  UX_SYNERGY_HC_CFIFOSEL;
            fifo_addr =  (VOID *)(hcd_synergy->ux_hcd_synergy_base + UX_SYNERGY_HC_CFIFO);
            fifo_ctrl =  UX_SYNERGY_HC_CFIFOCTR;
            break;
    }

    /* Get the FIFO access status for the endpoint.  */
    fifo_access_status =  ux_hcd_synergy_fifo_port_change(hcd_synergy, ed, 0);

    /* Check Status.  */
    if (fifo_access_status == (ULONG)UX_ERROR)
    {
        /* We have an error. Abort.  */
        return (UINT)UX_ERROR;
    }

    /* Get the max packet size for this endpoint.  */
    max_packet_size = ed -> ux_synergy_ed_endpoint -> ux_endpoint_descriptor.wMaxPacketSize;

    /* Isolate the payload length.  */
    payload_length = fifo_access_status & UX_SYNERGY_HC_FIFOCTR_DTLN;

    /* Get the TD used for this transfer.  */
    td =  ed->ux_synergy_ed_head_td;

    /* Save the payload length in the TD. This is needed to check for end of transfer.  */
    td -> ux_synergy_td_actual_length =  payload_length;

    /* Set NAK.  */
    ux_hcd_synergy_endpoint_nak_set(hcd_synergy, ed);

    /* Check for overwrite.  */
    if (td -> ux_synergy_td_length < payload_length)
    {
        /* Set Status to read overflow.  */
        status = (UINT)UX_SYNERGY_HC_FIFO_READ_OVER;

        /* Set the payload length to the size wanted by the caller.  */
        payload_length = td -> ux_synergy_td_length;
    }

    else
    {
        /* Check for short packet.  */
        if ((payload_length == 0UL) || ((payload_length % max_packet_size) != 0UL))
        {
            /* We have a short packet.  */
            status = (UINT)UX_SYNERGY_HC_FIFO_READ_SHORT;
        }
        else
        {
            /* Continue reading.  */
            status = (UINT)UX_SYNERGY_HC_FIFO_READING;
        }
    }

    /* Check for 0 length packet.  */
    if (payload_length == 0UL)
    {
        /* Set the BCLR flag.  */
        ux_hcd_synergy_register_set(hcd_synergy, fifo_ctrl, (USHORT)UX_SYNERGY_HC_FIFOCTR_BCLR);
    }
    else
    {
        /* Get the payload buffer address.  */
        payload_buffer =  td -> ux_synergy_td_buffer;

        /* Check we can use DMA for data transfer.  */
        if((hcd_synergy->ux_hcd_synergy_transfer.ux_synergy_transfer_rx != NULL) &&
                (ed -> ux_synergy_fifo_index == (ULONG)UX_SYNERGY_HC_FIFO_D1))
        {
#if defined(R_USBHS_BASE)
            if (R_USBHS_BASE == hcd_synergy->ux_hcd_synergy_base)
            {
                /* In DMA mode currently we only support word aligned access */
                if((((UINT)payload_buffer % 4) == 0) && (payload_length >= sizeof(UINT)))
                {
                    /* Wait until last DMA transfer completes */
                    _ux_utility_semaphore_get(&hcd_synergy->ux_hcd_synergy_semaphore_rx, UX_WAIT_FOREVER);
                }
            }
            else
#endif
            {
                /* Wait untill last DMA transfer completes */
                _ux_utility_semaphore_get(&hcd_synergy->ux_hcd_synergy_semaphore_rx, UX_WAIT_FOREVER);
            }
            /* Set transfer size.  */
#if defined(R_USBHS_BASE)
            if (R_USBHS_BASE == hcd_synergy->ux_hcd_synergy_base)
            {
                if(((UINT)payload_buffer % 4) == 0)
                {
                    /* We use 32 bits to transfer.  */
                    transfer_length_width = 4UL;
                    hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_rx.p_info->size   = TRANSFER_SIZE_4_BYTE;
                    hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_rx.p_info->length =
                            (uint16_t)(payload_length / 4U);
                    payload_length -= (ULONG)(hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_rx.p_info->length * 4U);

                    /* Set FIFO access width to 32 bits. */
                    ux_hcd_synergy_register_clear(hcd_synergy, fifo_sel, (USHORT)UX_SYNERGY_HC_DFIFOSEL_MBW_MASK);
                    ux_hcd_synergy_register_set(hcd_synergy, fifo_sel, (USHORT)UX_SYNERGY_HC_DFIFOSEL_MBW_32);
                }
                else if(((UINT)payload_buffer % 2) == 0)
                {
                    /* Currently supporting 16-bit aligned transfer via software copy */
                    ux_hcd_synergy_fifo_read_software_copy_16bit(hcd_synergy, payload_length, payload_buffer, fifo_addr,
                                                                 fifo_sel, fifo_ctrl);
                    return(status);
                }
                else
                {
                    /* Currently supporting 8-bit aligned transfer via software copy */
                    ux_hcd_synergy_fifo_read_software_copy_8bit(hcd_synergy, payload_length, payload_buffer, fifo_addr,
                                                                fifo_sel, fifo_ctrl);
                    return(status);
                }
            }
            else
#endif
            {
                if(((UINT)payload_buffer % 2) == 0)
                {
                    /* We use 16 bits to transfer.  */
                    transfer_length_width = 2UL;
                    hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_rx.p_info->size   = TRANSFER_SIZE_2_BYTE;
                    hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_rx.p_info->length =
                            (uint16_t)(payload_length / 2);
                    payload_length -= (ULONG)(hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_rx.p_info->length * 2);

                    /* Set FIFO access width to 16 bits. */
                    ux_hcd_synergy_register_clear(hcd_synergy, fifo_sel, (USHORT)UX_SYNERGY_HC_DFIFOSEL_MBW_MASK);
                    ux_hcd_synergy_register_set(hcd_synergy, fifo_sel, (USHORT)UX_SYNERGY_HC_DFIFOSEL_MBW_16);
                }
                else
                {
                    /* We use 8 bits to transfer.  */
                    transfer_length_width = 1UL;
                    hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_rx.p_info->size   = TRANSFER_SIZE_1_BYTE;
                    hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_rx.p_info->length = (uint16_t) payload_length;
                    payload_length -= (ULONG) hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_rx.p_info->length;

                    /* Set FIFO access width to 8 bits. */
                    ux_hcd_synergy_register_clear(hcd_synergy, fifo_sel, (USHORT)UX_SYNERGY_HC_DFIFOSEL_MBW_MASK);
                    ux_hcd_synergy_register_set(hcd_synergy, fifo_sel, (USHORT)UX_SYNERGY_HC_DFIFOSEL_MBW_8);
                }
            }
            /* Update the remaining bytes in payload to be transfered by software copy and the payload buffer
             * pointer. */
            hcd_synergy->remaining_payload_bytes = (uint16_t) payload_length;
            hcd_synergy->payload_buffer = payload_buffer;

            /* Check if we have at least 4bytes for 32-bit access or 2bytes for 16-bit access to do DMA transfer,
             * else do software copy to avoid software overhead required for DMA operation. */
            if(hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_rx.p_info->length != 0U)
            {
                /* Calculate the buffer offset to be used in DMA completion callback for remaining transfer. */
                hcd_synergy->payload_buffer += ((UINT)hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_rx.p_info->length
                        * (UINT)transfer_length_width);

                /* Setup DMA. */
                hcd_synergy->ux_hcd_synergy_transfer.ux_synergy_transfer_rx->p_api->blockReset(
                        hcd_synergy->ux_hcd_synergy_transfer.ux_synergy_transfer_rx->p_ctrl,
                        fifo_addr,
                        payload_buffer,
                        hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_rx.p_info->length,
                        hcd_synergy->ux_hcd_synergy_transfer_cfg_instance_rx.p_info->size,
                        1);

                /* Trigger DMA by software control. */
                hcd_synergy->ux_hcd_synergy_transfer.ux_synergy_transfer_rx->p_api->start(
                        hcd_synergy->ux_hcd_synergy_transfer.ux_synergy_transfer_rx->p_ctrl,
                        TRANSFER_START_MODE_SINGLE);
            }
            else
            {
                /* We have just few bytes so perform software copy with 8-bit FIFO access size. */
                ux_hcd_synergy_fifo_read_software_copy_8bit(hcd_synergy, payload_length, payload_buffer, fifo_addr,
                                                            fifo_sel, fifo_ctrl);
            }
        }
        else
        {
            /* Use software copy for data transfer. Currently we support 16-bit and 8-bit FIFO access width. */
            ux_hcd_synergy_fifo_read_software_copy(hcd_synergy, payload_length, payload_buffer, fifo_addr, fifo_sel,
                                                   fifo_ctrl);
        }
    }

    /* Return status about buffer transfer.  */
    return(status);
}

/******************************************************************************************************************//**
 * @brief  USBX HCD CPU FIFO read by software copy.  Call a suitable subroutine for selected USB controller hardware.
 *
 * @param[in]      hcd_synergy      Pointer to the HCD control block
 * @param[in]      payload_length   Payload length
 * @param[in]      payload_buffer   Payload buffer address
 * @param[in]      fifo_addr        FIFO register address
 * @param[in]      fifo_sel         FIFO select register
 * @param[in]      fifo_ctrl        FIFO control register
 **********************************************************************************************************************/
static VOID ux_hcd_synergy_fifo_read_software_copy(UX_HCD_SYNERGY *hcd_synergy,
                                                        ULONG payload_length,
                                                        UCHAR *payload_buffer,
                                                        VOID * fifo_addr,
                                                        ULONG  fifo_sel,
                                                        ULONG  fifo_ctrl)
{

    if(((UINT)payload_buffer % 2) == 0)
    {
        /* 16-bit software copy */
        ux_hcd_synergy_fifo_read_software_copy_16bit(hcd_synergy, payload_length, payload_buffer, fifo_addr,
                                                     fifo_sel, fifo_ctrl);
    }
    else
    {
        /* 8-bit software copy */
        ux_hcd_synergy_fifo_read_software_copy_8bit(hcd_synergy, payload_length, payload_buffer, fifo_addr,
                                                    fifo_sel, fifo_ctrl);
    }
}

/******************************************************************************************************************//**
 * @brief  USBX HCD CPU FIFO read - Software copy with 16-bit FIFO access
 *
 * @param[in]          hcd_synergy      Pointer to the HCD control block
 * @param[in,out]      payload_length   Payload length
 * @param[in,out]      payload_buffer   Payload buffer address
 * @param[in]          fifo_addr        FIFO register address
 * @param[in]          fifo_sel         FIFO select register
 * @param[in]          fifo_ctrl        FIFO control register
 **********************************************************************************************************************/
static VOID ux_hcd_synergy_fifo_read_software_copy_16bit(UX_HCD_SYNERGY *hcd_synergy,
                                                            ULONG payload_length,
                                                            UCHAR *payload_buffer,
                                                            VOID * fifo_addr,
                                                            ULONG  fifo_sel,
                                                            ULONG  fifo_ctrl)
{
    UINT fifo_access_times;

    /* Calculate FIFO access times. */
    fifo_access_times = (UINT)(payload_length / 2U);
    payload_length    = payload_length - ((ULONG)fifo_access_times * 2UL);

    /* Set FIFO access width to 16 bits. */
    ux_hcd_synergy_register_clear(hcd_synergy, fifo_sel, (USHORT)UX_SYNERGY_HC_DFIFOSEL_MBW_MASK);
    ux_hcd_synergy_register_set(hcd_synergy, fifo_sel, (USHORT)UX_SYNERGY_HC_DFIFOSEL_MBW_16);

    while (fifo_access_times != 0U)
    {
        /* Read 16 bits value.  */
        *(USHORT *)payload_buffer =  *(volatile USHORT *) fifo_addr;

        /* Update the payload buffer address.  */
        payload_buffer += sizeof(USHORT);

        /* And the remaining length.  */
        --fifo_access_times;
    }

    /* If we have a single byte to transfer */
    if(payload_length != 0UL)
    {
        USHORT  local_buffer;

        /* Read 16-bit value at once from FIFO to the local buffer. */
        local_buffer =  *(volatile USHORT *) fifo_addr;

        /* Only pick up 8-bit value. */
        *(UCHAR *)payload_buffer = (UCHAR)local_buffer;
    }
    /* Need to clear the buffer once complete data is read out. */
    ux_hcd_synergy_register_set(hcd_synergy, fifo_ctrl, UX_SYNERGY_HC_FIFOCTR_BCLR );
}

/*******************************************************************************************************************//**
 * @brief  USBX HCD CPU FIFO read - Software copy with 8-bit FIFO access
 *
 * @param[in]          hcd_synergy      Pointer to the HCD control block
 * @param[in,out]      payload_length   Payload length
 * @param[in,out]      payload_buffer   Payload buffer address
 * @param[in]          fifo_addr        FIFO register address
 * @param[in]          fifo_sel         FIFO select register
 * @param[in]          fifo_ctrl        FIFO control register
 **********************************************************************************************************************/
static VOID ux_hcd_synergy_fifo_read_software_copy_8bit(UX_HCD_SYNERGY *hcd_synergy,
                                                            ULONG payload_length,
                                                            UCHAR *payload_buffer,
                                                            VOID * fifo_addr,
                                                            ULONG  fifo_sel,
                                                            ULONG  fifo_ctrl)
{
    /* Set FIFO access to 8 bits. */
    ux_hcd_synergy_register_clear(hcd_synergy, fifo_sel, (USHORT)UX_SYNERGY_HC_DFIFOSEL_MBW_MASK);
    ux_hcd_synergy_register_set(hcd_synergy, fifo_sel, (USHORT)UX_SYNERGY_HC_DFIFOSEL_MBW_8);

    while (payload_length != 0UL)
    {
        /* Read 8 bits value.  */
        *payload_buffer =  *(volatile UCHAR *) fifo_addr;

        /* Update the payload buffer address.  */
        payload_buffer += sizeof(UCHAR);

        /* And the remaining length.  */
        payload_length -= sizeof(UCHAR);
    }
    /* Need to clear the buffer once complete data is read out. */
    ux_hcd_synergy_register_set(hcd_synergy, fifo_ctrl, UX_SYNERGY_HC_FIFOCTR_BCLR );
}
/*******************************************************************************************************************//**
 * @} (end addtogroup sf_el_ux)
 **********************************************************************************************************************/
