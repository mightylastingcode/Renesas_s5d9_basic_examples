/*

    Project: ADC Lesson
    Name:    Michael Li
    Company: Consultant
    Web page: https://www.miketechuniverse.com/
    Date:    1/9/18

    SSP version: 1.30
    E2 Studio version: 5.4.0.023

    Description:  The ADC (P0_1 AN01 MIC U10) will measure the analog voltage level.  It is set
                  for an 12 bits resolution.

                  AN000 to AN0006 has +/= 4.5 LSB

                  3.3 Vref * 4.5 / 2^12 bit resolution = 3.626E-3

*/

#include "system_thread.h"

#include <stdio.h>
#include <string.h>

// Buffer Size
#define UART_BUFFER_SIZE 1024

// Tick Rate
#define COUNTS_PER_MILLISECOND  (120E6 / 1000)

uint8_t string[132];

/* System Thread entry function */
void system_thread_entry(void)
{
    // Variable to hold ADC Data
    uint16_t adcCounts;
    uint16_t adcCounts2;
    float adcVoltage;
    float adcVoltage2;

    // Open the ADC
    g_adc.p_api->open (g_adc.p_ctrl, g_adc.p_cfg);

    // Configure Scan
    g_adc.p_api->scanCfg (g_adc.p_ctrl, g_adc.p_channel_cfg);

    // Start ADC Scan
    g_adc.p_api->scanStart (g_adc.p_ctrl);

    while (1)
    {
        // Read ADC
        //g_adc.p_api->read (g_adc.p_ctrl, ADC_REG_CHANNEL_0, &adcCounts);
        g_adc.p_api->read (g_adc.p_ctrl, ADC_REG_CHANNEL_1, &adcCounts2);

        // Convert Counts to Voltage
        //adcVoltage = ((adcCounts * 3.3f) / 4095.0f);  // 12 bits resolution.  range: 0 to 3.3V
        adcVoltage2 = ((adcCounts2 * 3.3f) / 4095.0f);

        sprintf((char *)string,"adcCounts2:  %5d   adcVoltage2: %5.2f\r\n",adcCounts2,adcVoltage2);
        g_sf_comms0.p_api->write(g_sf_comms0.p_ctrl, string, (uint32_t)strlen((char *)string), TX_WAIT_FOREVER);

        tx_thread_sleep (1);
    }
}


